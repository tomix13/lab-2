public class JpegFileViewer extends FileViewer{

    public void readData(){
        Log.consoleOutput("Чтение jpeg файла...");
    }

    public void renderData() {
        Log.consoleOutput("Вывод jpeg файла...");
    }
}
