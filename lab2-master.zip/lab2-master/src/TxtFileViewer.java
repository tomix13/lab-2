public class TxtFileViewer extends FileViewer {

    public void readData(){
        Log.consoleOutput("Чтение текстового файла...");
    }

    public void renderData() {
        Log.consoleOutput("Вывод текстового файла...");
    }


}
