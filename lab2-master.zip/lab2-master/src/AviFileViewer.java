public class AviFileViewer extends FileViewer {

    public void readData(){
        Log.consoleOutput("Чтение avi файла...");
    }

    public void renderData() {
        Log.consoleOutput("Вывод avi файла...");
    }
}
