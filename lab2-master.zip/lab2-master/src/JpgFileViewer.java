public class JpgFileViewer extends FileViewer {

    public void readData(){
        Log.consoleOutput("Чтение jpg файла...");
    }

    public void renderData() {
        Log.consoleOutput("Вывод jpg файла...");
    }
}
